import React from 'react';
import { Check } from 'lucide-react';

const Pricing: React.FC = () => {
  const plans = [
    {
      name: "BASIC",
      price: "29",
      features: ["Access to Gym Floor", "Locker Room Access", "Free WiFi", "1 Guest Pass/Month"],
      isPopular: false
    },
    {
      name: "PRO",
      price: "49",
      features: ["All Basic Features", "Unlimited Group Classes", "Sauna Access", "Free Fitness Assessment"],
      isPopular: true
    },
    {
      name: "LEGEND",
      price: "89",
      features: ["All Pro Features", "2 Personal Training Sessions", "Nutrition Plan", "Priority Support"],
      isPopular: false
    }
  ];

  return (
    <div className="py-24 bg-dark bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-neon font-bold tracking-widest uppercase mb-2">Membership Plans</h2>
          <h3 className="text-3xl md:text-5xl font-heading font-black text-white">CHOOSE YOUR POWER</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          {plans.map((plan, index) => (
            <div 
              key={index} 
              className={`relative bg-dark-secondary rounded-2xl p-8 border transition-all duration-300 ${
                plan.isPopular 
                  ? 'border-neon scale-105 shadow-[0_0_30px_rgba(57,255,20,0.15)] z-10' 
                  : 'border-white/10 hover:border-white/30'
              }`}
            >
              {plan.isPopular && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-neon text-black font-black uppercase text-xs px-4 py-1 rounded-full tracking-wider">
                  Best Value
                </div>
              )}
              
              <div className="text-center mb-8">
                <h4 className="text-xl font-bold text-white mb-2">{plan.name}</h4>
                <div className="flex justify-center items-end text-white">
                  <span className="text-2xl font-bold mb-1 opacity-50">$</span>
                  <span className="text-5xl font-heading font-black">{plan.price}</span>
                  <span className="text-gray-400 mb-1 ml-1">/mo</span>
                </div>
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center gap-3 text-gray-300 text-sm">
                    <div className={`rounded-full p-1 ${plan.isPopular ? 'bg-neon text-black' : 'bg-gray-800 text-gray-400'}`}>
                      <Check className="w-3 h-3" strokeWidth={3} />
                    </div>
                    {feature}
                  </li>
                ))}
              </ul>

              <button 
                className={`w-full py-4 rounded-xl font-bold uppercase tracking-wider transition-all duration-300 ${
                  plan.isPopular 
                    ? 'bg-neon text-black hover:bg-white' 
                    : 'bg-white/5 text-white hover:bg-white/10'
                }`}
              >
                Choose {plan.name}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Pricing;