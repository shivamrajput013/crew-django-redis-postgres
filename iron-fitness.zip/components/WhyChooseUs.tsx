import React from 'react';
import { CheckCircle2 } from 'lucide-react';

const WhyChooseUs: React.FC = () => {
  const benefits = [
    "Personalized Nutrition Plans",
    "Small Group HIIT Classes",
    "Recovery Sauna & Cold Plunge",
    "Dedicated Mobile App"
  ];

  return (
    <div className="py-20 bg-dark-secondary overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          
          {/* Image Side */}
          <div className="w-full lg:w-1/2 relative group">
            <div className="absolute -inset-4 bg-neon opacity-20 blur-2xl rounded-xl group-hover:opacity-30 transition-opacity duration-500"></div>
            <div className="relative rounded-xl overflow-hidden shadow-2xl transform transition-transform hover:scale-[1.01]">
              <img 
                src="https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?q=80&w=2070&auto=format&fit=crop" 
                alt="Athlete training" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-8">
                <div>
                  <p className="text-neon font-bold text-lg mb-1">#IronMentality</p>
                  <p className="text-white text-sm">Join 5,000+ members pushing their limits daily.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Text Side */}
          <div className="w-full lg:w-1/2">
            <h2 className="text-neon font-bold tracking-widest uppercase mb-2">The Difference</h2>
            <h3 className="text-3xl md:text-5xl font-heading font-black text-white mb-6">
              MORE THAN JUST <br/> A GYM
            </h3>
            <p className="text-gray-400 text-lg mb-8 leading-relaxed">
              We don't just provide machines; we provide a lifestyle. Iron Fitness is built on the philosophy that true strength comes from consistency, community, and expert guidance.
            </p>

            <ul className="space-y-4 mb-10">
              {benefits.map((benefit, index) => (
                <li key={index} className="flex items-center gap-3 text-white font-medium">
                  <CheckCircle2 className="text-neon w-6 h-6 flex-shrink-0" />
                  {benefit}
                </li>
              ))}
            </ul>

            <button className="text-white border-b-2 border-neon pb-1 hover:text-neon transition-colors text-lg font-bold">
              Read Success Stories &rarr;
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};

export default WhyChooseUs;