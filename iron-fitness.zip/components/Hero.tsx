import React from 'react';
import { ChevronRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat bg-fixed"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop")',
        }}
      >
        <div className="absolute inset-0 bg-black/60 bg-gradient-to-t from-dark via-transparent to-black/40"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-20">
        <h2 className="text-neon font-bold tracking-widest text-sm md:text-base mb-4 uppercase animate-pulse">
          Welcome to the next level
        </h2>
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-heading font-black text-white mb-6 leading-tight">
          TRANSFORM YOUR <br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-500">BODY IN 90 DAYS</span>
        </h1>
        <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-300 mb-10">
          Join the city's top-rated fitness community. State-of-the-art equipment, expert coaching, and a culture that pushes you to be your best.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button className="group relative bg-neon text-black font-bold px-8 py-4 rounded-full text-lg overflow-hidden hover:scale-105 transition-transform duration-300">
            <span className="relative z-10 flex items-center gap-2">
              START FREE TRIAL <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </span>
            <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20 transition-opacity"></div>
          </button>
          
          <button className="px-8 py-4 rounded-full text-lg font-bold border-2 border-white text-white hover:bg-white hover:text-black transition-all duration-300">
            VIEW SCHEDULE
          </button>
        </div>
      </div>
    </div>
  );
};

export default Hero;