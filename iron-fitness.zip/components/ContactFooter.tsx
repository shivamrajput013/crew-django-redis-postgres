import React, { useState } from 'react';
import { Facebook, Instagram, Twitter, MapPin, Phone, Mail } from 'lucide-react';

const ContactFooter: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thanks for joining the waitlist! We will contact you shortly.');
    setFormData({ name: '', email: '', phone: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <footer className="bg-black pt-20 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-20">
          {/* Form */}
          <div>
            <h3 className="text-3xl font-heading font-black text-white mb-2">START YOUR JOURNEY</h3>
            <p className="text-gray-400 mb-8">Book a free session today. No commitment required.</p>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <input 
                  type="text" 
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Full Name" 
                  className="w-full bg-dark-secondary border border-white/10 rounded-lg px-5 py-4 text-white placeholder-gray-500 focus:outline-none focus:border-neon transition-colors"
                  required 
                />
              </div>
              <div>
                <input 
                  type="email" 
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="Email Address" 
                  className="w-full bg-dark-secondary border border-white/10 rounded-lg px-5 py-4 text-white placeholder-gray-500 focus:outline-none focus:border-neon transition-colors"
                  required 
                />
              </div>
              <div>
                <input 
                  type="tel" 
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="Phone Number" 
                  className="w-full bg-dark-secondary border border-white/10 rounded-lg px-5 py-4 text-white placeholder-gray-500 focus:outline-none focus:border-neon transition-colors"
                  required 
                />
              </div>
              <button 
                type="submit"
                className="w-full bg-neon text-black font-bold text-lg px-8 py-4 rounded-lg hover:bg-white hover:scale-[1.02] transition-all duration-300 uppercase"
              >
                Book Free Session
              </button>
            </form>
          </div>

          {/* Contact Info */}
          <div className="flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-8">
                <span className="font-heading font-black text-3xl italic text-white">
                  IRON<span className="text-neon">FITNESS</span>
                </span>
              </div>
              <p className="text-gray-400 leading-relaxed mb-8 max-w-md">
                We are more than a gym. We are a community of individuals striving for greatness. Come visit us and see the difference.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4 text-gray-300">
                  <MapPin className="text-neon mt-1 w-5 h-5" />
                  <span>123 Iron Street, Muscle Beach<br/>Venice, CA 90291</span>
                </div>
                <div className="flex items-center gap-4 text-gray-300">
                  <Phone className="text-neon w-5 h-5" />
                  <span>+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center gap-4 text-gray-300">
                  <Mail className="text-neon w-5 h-5" />
                  <span>join@ironfitness.com</span>
                </div>
              </div>
            </div>

            <div className="flex gap-4 mt-10">
              <a href="#" className="bg-dark-secondary p-3 rounded-full hover:bg-neon hover:text-black transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="bg-dark-secondary p-3 rounded-full hover:bg-neon hover:text-black transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="bg-dark-secondary p-3 rounded-full hover:bg-neon hover:text-black transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 py-8 text-center text-gray-500 text-sm">
          &copy; {new Date().getFullYear()} Iron Fitness Inc. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default ContactFooter;