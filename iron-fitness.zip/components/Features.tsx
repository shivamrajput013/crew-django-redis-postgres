import React from 'react';
import { Users, Bike, Clock } from 'lucide-react';

const Features: React.FC = () => {
  const features = [
    {
      icon: <Users className="w-10 h-10 text-neon" />,
      title: "Expert Trainers",
      description: "Our certified coaches are here to guide your journey with personalized plans and motivation."
    },
    {
      icon: <Bike className="w-10 h-10 text-neon" />,
      title: "Modern Equipment",
      description: "Train with the latest Technogym and Rogue Fitness gear designed for peak performance."
    },
    {
      icon: <Clock className="w-10 h-10 text-neon" />,
      title: "24/7 Access",
      description: "Work out on your schedule. We never close, so you never have to miss a session."
    }
  ];

  return (
    <div className="py-24 bg-dark relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-neon font-bold tracking-widest uppercase mb-2">Why Iron Fitness</h2>
          <h3 className="text-3xl md:text-5xl font-heading font-black text-white">PUSH YOUR LIMITS</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-dark-secondary p-8 rounded-2xl border border-white/5 hover:border-neon/50 transition-colors duration-300 group hover:-translate-y-2 transform"
            >
              <div className="bg-black/50 w-20 h-20 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 border border-white/10 group-hover:border-neon">
                {feature.icon}
              </div>
              <h4 className="text-xl font-bold text-white mb-3">{feature.title}</h4>
              <p className="text-gray-400 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Features;