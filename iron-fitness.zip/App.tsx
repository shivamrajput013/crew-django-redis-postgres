import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import WhyChooseUs from './components/WhyChooseUs';
import Pricing from './components/Pricing';
import ContactFooter from './components/ContactFooter';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-dark text-white font-sans selection:bg-neon selection:text-black">
      <Navbar />
      <main>
        <section id="home">
          <Hero />
        </section>
        <section id="features">
          <Features />
        </section>
        <section id="about">
          <WhyChooseUs />
        </section>
        <section id="pricing">
          <Pricing />
        </section>
        <section id="contact">
          <ContactFooter />
        </section>
      </main>
    </div>
  );
};

export default App;